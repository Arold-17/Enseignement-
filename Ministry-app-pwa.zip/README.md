# Mon Ministère — Application PWA

Fonctionnalités :
- 📖 Cours (CRUD complet via Admin)
- ✝️ Verset du jour (liste éditable)
- ❓ Quiz (questions à choix multiples)
- 📅 Événements (agenda local)
- 🙏 Demandes de prière (formulaire + liste locale)
- 📦 Export / 📥 Import JSON
- 📱 Installable + hors-ligne (service worker)

## Lancer en local
```bash
python -m http.server 8080
```
Puis ouvrir http://localhost:8080

## Déploiement gratuit
- GitHub Pages / Netlify / Vercel (dossier statique à déposer)
