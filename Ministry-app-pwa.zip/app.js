// app.js
// --- Storage keys ---
const K = {
  COURSES: 'min_courses',
  VERSES: 'min_verses',
  QUIZ: 'min_quiz',
  EVENTS: 'min_events',
  PRAYERS: 'min_prayers'
};

// --- Default seed data (only on first run) ---
function seed(key, value) {
  if (!localStorage.getItem(key)) localStorage.setItem(key, JSON.stringify(value));
}
seed(K.COURSES, [
  {id: crypto.randomUUID(), title:'La Foi', body:"La foi est une ferme assurance des choses qu\'on espère (Hé 11:1).", video:''},
  {id: crypto.randomUUID(), title:'La Prière', body:"Priez sans cesse (1 Th 5:17).", video:''}
]);
seed(K.VERSES, ["L'Éternel est mon berger: je ne manquerai de rien. (Ps 23:1)", "Je puis tout par celui qui me fortifie. (Ph 4:13)"]);
seed(K.QUIZ, [{question:"Qui a construit l'arche ?", choices:["Moïse","Noé","Abraham"], answer:1}]);
seed(K.EVENTS, []);
seed(K.PRAYERS, []);

// --- Helpers ---
const $ = sel => document.querySelector(sel);
const listEl = sel => document.getElementById(sel);

// Navigation
window.show = id => {
  document.querySelectorAll('main section').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  if (id==='courses') renderCourses();
  if (id==='verse') renderVerse();
  if (id==='quiz') renderQuiz();
  if (id==='events') renderEvents();
  if (id==='prayer') renderPrayers();
};

// --- Courses ---
function getCourses(){ return JSON.parse(localStorage.getItem(K.COURSES)||'[]'); }
function setCourses(v){ localStorage.setItem(K.COURSES, JSON.stringify(v)); }

function renderCourses(){
  const courses = getCourses();
  const container = listEl('courseList');
  container.innerHTML = '';
  listEl('noCourses').textContent = courses.length? '' : "Aucun cours pour le moment.";
  courses.forEach(c => {
    const div = document.createElement('div');
    div.className = 'item';
    const left = document.createElement('div');
    left.innerHTML = `<b>${c.title}</b><div class='muted'>${c.body.slice(0,80)}${c.body.length>80?'…':''}</div>`;
    const actions = document.createElement('div');
    actions.className = 'actions';
    const view = btn('Voir', () => viewCourse(c));
    const edit = btn('Modifier', () => editCourse(c));
    const del = btn('Supprimer', () => { if(confirm('Supprimer ce cours ?')) { removeCourse(c.id); renderCourses(); } });
    actions.append(view, edit, del);
    div.append(left, actions);
    container.appendChild(div);
  });
}

function btn(label, onClick){ const b=document.createElement('button'); b.className='ghost'; b.textContent=label; b.onclick=onClick; return b; }

function viewCourse(c){
  alert(`${c.title}\n\n${c.body}`);
}

function editCourse(c){
  $('#cId').value = c.id;
  $('#cTitle').value = c.title;
  $('#cBody').value = c.body;
  $('#cVideo').value = c.video || '';
  window.show('admin');
}

function removeCourse(id){
  const arr = getCourses().filter(x => x.id!==id);
  setCourses(arr);
}

function resetCourseForm(){
  $('#cId').value=''; $('#cTitle').value=''; $('#cBody').value=''; $('#cVideo').value='';
}

document.getElementById('courseForm').addEventListener('submit', e => {
  e.preventDefault();
  const id = $('#cId').value || crypto.randomUUID();
  const title = $('#cTitle').value.trim();
  const body = $('#cBody').value.trim();
  const video = $('#cVideo').value.trim();
  if(!title || !body) return;
  let arr = getCourses();
  const idx = arr.findIndex(x => x.id===id);
  if (idx>=0) arr[idx] = {id, title, body, video};
  else arr.push({id, title, body, video});
  setCourses(arr);
  resetCourseForm();
  alert('Cours enregistré !');
});

// --- Verse of the day ---
function getVerses(){ return JSON.parse(localStorage.getItem(K.VERSES)||'[]'); }
function setVerses(v){ localStorage.setItem(K.VERSES, JSON.stringify(v)); }
function renderVerse(){
  const verses = getVerses();
  const v = verses[Math.floor(Math.random()*verses.length)] || 'Ajoutez des versets dans Admin.';
  listEl('verseContent').textContent = v;
}
document.getElementById('verseForm').addEventListener('submit', e => {
  e.preventDefault();
  const t = $('#vText').value.trim();
  if (!t) return;
  const arr = getVerses(); arr.push(t); setVerses(arr);
  e.target.reset(); alert('Verset ajouté !');
});

// --- Quiz ---
function getQuizzes(){ return JSON.parse(localStorage.getItem(K.QUIZ)||'[]'); }
function setQuizzes(v){ localStorage.setItem(K.QUIZ, JSON.stringify(v)); }
function renderQuiz(){
  const quizzes = getQuizzes();
  const wrap = listEl('quizContent'); wrap.innerHTML='';
  if (quizzes.length===0){ wrap.textContent='Ajoutez un quiz dans Admin.'; return; }
  const quiz = quizzes[Math.floor(Math.random()*quizzes.length)];
  const q = document.createElement('div');
  q.innerHTML = `<p><b>${quiz.question}</b></p>`;
  quiz.choices.forEach((ch,i)=>{
    const b = document.createElement('button'); b.className='ghost'; b.textContent=ch; b.style.margin='4px';
    b.onclick = () => alert(i===quiz.answer ? 'Bonne réponse !' : 'Essaie encore.');
    q.appendChild(b);
  });
  wrap.appendChild(q);
}

document.getElementById('quizForm').addEventListener('submit', e => {
  e.preventDefault();
  const question = $('#qQuestion').value.trim();
  const choices = [$('#qA').value.trim(), $('#qB').value.trim(), $('#qC').value.trim()];
  const answer = parseInt($('#qAnswer').value,10);
  if(!question || choices.some(x=>!x) || isNaN(answer)) return;
  const arr = getQuizzes(); arr.push({question, choices, answer}); setQuizzes(arr);
  e.target.reset(); alert('Quiz ajouté !');
});

// --- Events ---
function getEvents(){ return JSON.parse(localStorage.getItem(K.EVENTS)||'[]'); }
function setEvents(v){ localStorage.setItem(K.EVENTS, JSON.stringify(v)); }
function renderEvents(){
  const events = getEvents().sort((a,b)=> (a.date||'').localeCompare(b.date));
  const container = listEl('eventList'); container.innerHTML='';
  listEl('noEvents').textContent = events.length? '' : "Aucun événement à venir.";
  events.forEach(ev => {
    const div = document.createElement('div'); div.className='item';
    const left = document.createElement('div');
    const when = [ev.date, ev.time].filter(Boolean).join(' · ');
    left.innerHTML = `<b>${ev.title}</b><div class='muted'>${when} ${ev.place? ' · '+ev.place:''}</div>`;
    const actions = document.createElement('div'); actions.className='actions';
    const del = btn('Supprimer', () => { if(confirm('Supprimer cet événement ?')){ setEvents(getEvents().filter(x=>x.id!==ev.id)); renderEvents(); } });
    actions.append(del);
    div.append(left, actions);
    container.appendChild(div);
  });
}
document.getElementById('eventForm').addEventListener('submit', e => {
  e.preventDefault();
  const ev = { id: crypto.randomUUID(), title: $('#eTitle').value.trim(), date: $('#eDate').value, time: $('#eTime').value, place: $('#ePlace').value.trim() };
  if(!ev.title || !ev.date) return;
  const arr = getEvents(); arr.push(ev); setEvents(arr);
  e.target.reset(); alert('Événement ajouté !'); renderEvents();
});

// --- Prayers ---
function getPrayers(){ return JSON.parse(localStorage.getItem(K.PRAYERS)||'[]'); }
function setPrayers(v){ localStorage.setItem(K.PRAYERS, JSON.stringify(v)); }
function renderPrayers(){
  const arr = getPrayers();
  const list = listEl('prayerList'); list.innerHTML='';
  arr.slice().reverse().forEach(p => {
    const div = document.createElement('div'); div.className='item';
    const meta = [p.name||'Anonyme', p.contact||''].filter(Boolean).join(' · ');
    div.innerHTML = `<div><b>${meta}</b><div class='muted'>${new Date(p.ts).toLocaleString()}</div><div>${p.message}</div></div>`;
    const actions = document.createElement('div'); actions.className='actions';
    const del = btn('Supprimer', () => { setPrayers(getPrayers().filter(x=>x.id!==p.id)); renderPrayers(); });
    actions.append(del);
    div.appendChild(actions);
    list.appendChild(div);
  });
}
document.getElementById('prayerForm').addEventListener('submit', e => {
  e.preventDefault();
  const p = { id: crypto.randomUUID(), name: $('#pName').value.trim(), contact: $('#pContact').value.trim(), message: $('#pMessage').value.trim(), ts: Date.now() };
  if(!p.message) return;
  const arr = getPrayers(); arr.push(p); setPrayers(arr);
  e.target.reset(); alert('Demande envoyée !'); renderPrayers();
});

// --- Export / Import / Reset ---
window.exportData = function(){
  const data = {
    courses: getCourses(),
    verses: getVerses(),
    quizzes: getQuizzes(),
    events: getEvents(),
    prayers: getPrayers()
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'ministry-data.json'; a.click();
  URL.revokeObjectURL(url);
};

window.importData = function(e){
  const file = e.target.files[0]; if(!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    try{
      const d = JSON.parse(ev.target.result);
      if (d.courses) setCourses(d.courses.map(x=>({id: x.id||crypto.randomUUID(), title:x.title, body:x.body, video:x.video||''})));
      if (d.verses) setVerses(d.verses);
      if (d.quizzes) setQuizzes(d.quizzes);
      if (d.events) setEvents(d.events.map(x=>({id: x.id||crypto.randomUUID(), title:x.title, date:x.date, time:x.time||'', place:x.place||''})));
      if (d.prayers) setPrayers(d.prayers);
      alert('Données importées. Recharge la page pour tout actualiser.');
    }catch(err){ alert('Fichier invalide.'); }
  };
  reader.readAsText(file);
};

window.resetAll = function(){
  Object.values(K).forEach(k => localStorage.removeItem(k));
  alert('Toutes les données locales ont été effacées.');
};
